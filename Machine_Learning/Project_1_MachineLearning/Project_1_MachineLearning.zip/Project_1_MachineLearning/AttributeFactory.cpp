//
//  AttributeFactory.cpp
//  Project_1_MachineLearning
//
//  Created by Konrad Rauscher on 2/3/16.
//  Copyright © 2016 Konrad Rauscher. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>

#include "AttributeFactory.h"



 Attribute * AttributeFactory::make( const vector<string> &data ) throw ( logic_error )
{

    if (data[1] == "numeric") { // attribute is numeric
        
        
        Attribute * numAtt = new NumericAttribute(data[0]);

//        cout <<  "New num is: ";
//        dynamic_cast<NumericAttribute *>(numAtt)->print();
//        cout << endl;
        return numAtt;
        

    }
    else{
        Attribute * nomAtt = new NominalAttribute(data[0]);
        
//        cout << "added values: " << endl;
        for (int i = 1; i < data.size(); i++) {                        
            dynamic_cast<NominalAttribute *>(nomAtt)->addValue(data[i]);
             //cout << data[i] << " ";
        }

        return nomAtt;
        
    }
}