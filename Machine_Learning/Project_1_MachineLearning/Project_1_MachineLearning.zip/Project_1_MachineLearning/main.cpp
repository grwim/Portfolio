//
// Konrad Rauscher
// kr623@georgetown.edu
// Platform: OS X
// Language/Environment: c++
//
// In accordance with the class policies and Georgetown's Honor Code,
// I certify that, with the exceptions of the class resources and those
// items noted below, I have neither given nor received any assistance
// on this project.
//

#include <iostream>
#include <sstream>
#include "Attribute.h"
#include "Example.h"
#include "AttributeFactory.h"
#include "NumericAttribute.h"
#include "NominalAttribute.h"
#include "Attributes.h"
#include "TrainTestSets.h"
#include "DataSet.h"
#include "Examples.h"

// README
// MAKEFILE

using namespace std;

int main(int argc, const char * argv[]) {
    
    string fileOpenError = "";
    vector<string> options;
    
    try {
        
        for (int i = 1; i < argc; i++) {
            string s(argv[i]);
            options.push_back(s);
        }
        
        TrainTestSets tts;
        
        tts.setOptions(options);
        
        tts.print();
        
    } catch (string error) {
        cout << error;
    }
    
    cout << "Ending Main" << endl;
    return 0;
    
}
