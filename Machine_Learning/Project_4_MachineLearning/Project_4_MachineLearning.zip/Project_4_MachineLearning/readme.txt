Konrad Rauscher 4/15/2016
Machine Learning
Project 4

Command args specific for BP:
-l <double>   —> specify learning rate 
-m <double>   —> specify minError rate
-n <int>   —> specify number of internal nodes 
