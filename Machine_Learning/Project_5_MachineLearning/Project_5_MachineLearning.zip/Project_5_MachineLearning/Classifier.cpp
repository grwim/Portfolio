//
//  Classifier.cpp
//  Project_5_MachineLearning
//
//  Created by Konrad Rauscher on 4/24/16.
//  Copyright © 2016 Konrad Rauscher. All rights reserved.
//

#include "Classifier.hpp"

void Classifier::train(const DataSet & myDataSet)
{
    
}

Performance Classifier::classify(const DataSet & myDataSet) // will call classify( Example ) for each example in the data set, will takea a prediction from classify( Example ), decides if it is correct or incorrect, and computes the accuracy over the examples of the DataSet, returning it as a Performance object.
{
    
    
    Performance bleh;
    return bleh;
}

int Classifier::classify(const Example & myExample)
{
    
    return 0;
}

