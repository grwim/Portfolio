Konrad Rauscher 5/2/2016
Machine Learning
Project 5 - ForestRI

Command args:
-x <int> 	-> specify # of folds for k-fold cross validation
-p <double> 	—> specify proportion for hold out

Command args specific for ForestRI:
-k <int>   —> specify # of non-zero gain attributes available to each split choice 
-b <int>   —> specify size of forest

defaults of k and b are 7 and 3, respectively 
